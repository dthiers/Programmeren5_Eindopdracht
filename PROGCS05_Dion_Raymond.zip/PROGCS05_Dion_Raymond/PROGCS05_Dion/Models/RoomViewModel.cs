﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PROGCS05_Dion.Models {
    public class RoomViewModel {
        public int Id { get; set; }
        public string Capaciteit { get; set; }
    }
}